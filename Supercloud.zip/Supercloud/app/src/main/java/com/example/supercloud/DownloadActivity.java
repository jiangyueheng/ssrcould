package com.example.supercloud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class DownloadActivity extends AppCompatActivity {

    protected static final String TAG = "jyh";
    private TextView authorView,musicView,albumView;
    private Button button;
    private MusicDB musicDB;
    private SQLiteDatabase DBWriter;

    private String url,name,id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);

        musicDB = new MusicDB(this);
        DBWriter = musicDB.getWritableDatabase();

        button = (Button) findViewById(R.id.download_main_Button);
        authorView = (TextView) findViewById(R.id.author);
        musicView = (TextView)findViewById(R.id.musicname);
        albumView = (TextView)findViewById(R.id.album);

        name = getIntent().getStringExtra("onlistenname");
        id = getIntent().getStringExtra("onlistenid");
        url = getIntent().getStringExtra("onlistenurl");
        musicView.setText(name);
        authorView.setText(getIntent().getStringExtra("author"));
        albumView.setText(getIntent().getStringExtra("album"));
        //url= "https://music.163.com/song/media/outer/url?id="+id+".mp3";
        Log.d(TAG, "获得数据"+id+name+url);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(url.equals("null")){
                    Toast.makeText(getApplicationContext(), "无法获得url无法下载" , Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent=new Intent(DownloadActivity.this,MyIntentService.class);
                    Bundle bundle=new Bundle();
                    bundle.putString("url",url);
                    bundle.putString("path","/Download/");
                    bundle.putString("name",name+id+".mp3");
                    //bundle.putString("key","path");
                    intent.putExtras(bundle);
                    startService(intent);
                    addDB();
                }


            }
        });

    }

    public class KongqwBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 获得广播发送的数据
            Log.d(TAG, "收到广播");
            String kind = intent.getStringExtra("kind");
            if(kind.equals("0")){
                Toast.makeText(context, "开始下载" , Toast.LENGTH_SHORT).show();
                Log.d(TAG, "开始下载");
            }else if(kind.equals("2")){
                Toast.makeText(context, "下载完成" , Toast.LENGTH_SHORT).show();
            }

        }
    }
    private void addDB(){
        ContentValues cv = new ContentValues();
        cv.put(MusicDB.NAME,musicView.getText().toString());
        cv.put(MusicDB.MUSICID,id);
        cv.put(MusicDB.AUTHOR,authorView.getText().toString());
        cv.put(MusicDB.ALBUM,albumView.getText().toString());
        cv.put(MusicDB.PATH,"/Download/"+name+id+".mp3");
        DBWriter.insert(MusicDB.TABLE_NAME,null,cv);
    }
    @Override
    protected void onDestroy() {
        DBWriter.close();
        super.onDestroy();
    }
}