package com.example.supercloud;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    protected static final String TAG = "jyh";
    private EditText sousuotext;
    private List<MusicBean> list;
    public static final int FindMUSICURL = 15313213;
    private ListView musiclist;
    private String musicdata[] = new String[100];
    private MusicBean onlisten=new MusicBean();
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            String response = (String) msg.obj;
            System.out.println("aa"+response);
            int i=0;
            Log.d(TAG, "findwhat"+msg.what);
            switch (msg.what) {

                case 0:{
                    // 在这⾥进⾏UI操作，将结果显示到界⾯上
                    list = parseJSONWithJOSNObject(response.toString());
                    for(i=0;i<list.size();i++){
                        musicdata[i]=list.get(i).getName();
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,musicdata);//新建并配置ArrayAapeter
                    musiclist.setAdapter(adapter);
                    break;
                }


                case 15313213:
                {
                    Log.d(TAG, "findmusicurl"+response);
                    Intent intent = new Intent(MainActivity.this,DownloadActivity.class);
                    onlisten.setUrl(response);
                    intent.putExtra("onlistenname", onlisten.getName());
                    intent.putExtra("onlistenid", onlisten.getId());
                    intent.putExtra("onlistenurl",getmusicurl(response));
                    intent.putExtra("imgurl",onlisten.getImagurl());
                    intent.putExtra("album",onlisten.getAlbum());
                    intent.putExtra("author",onlisten.getAuthorname());

                    startActivity(intent);
                    break;
                }




            }


        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sousuotext = (EditText)findViewById(R.id.sousuo);
        musiclist = (ListView)findViewById(R.id.musiclist);
        musiclist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this,"你点击了"+musicdata[i]+"按钮",Toast.LENGTH_SHORT).show();
                onlisten=list.get(i);
                getmusicurljson(list.get(i));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        try {
            Class<?> clazz = Class.forName("android.support.v7.view.menu.MenuBuilder");
            Method m = clazz.getDeclaredMethod("setOptionalIconsVisible", boolean.class);
            m.setAccessible(true);
            //MenuBuilder实现Menu接口，创建菜单时，传进来的menu其实就是MenuBuilder对象(java的多态特征)
            m.invoke(menu,true);//交出控制权
        } catch (Exception e) {
            e.printStackTrace();
        }
        return super.onCreateOptionsMenu(menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        switch (id){
            case R.id.add:
                Toast.makeText(MainActivity.this,"查看下载",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,SelectActivity.class);


                startActivity(intent);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    //获取歌单,歌曲urljson
    public void emirituijianmusic(){
        new Thread(new Runnable() {

            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {

                    URL url = new URL("https://netease-cloud-music-api-mocha-kappa.vercel.app/search?keywords= "+sousuotext.getText().toString());
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new
                            InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null)
                        response.append(line);
                    Message message = new Message();
                    message.what = 0;
                    message.obj = response.toString();
                    handler.sendMessage(message);
                    System.out.println("response"+response.toString());

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (connection != null)
                        connection.disconnect();

                }
            }
        }).start();

    }




//解析歌单json
    private List<MusicBean> parseJSONWithJOSNObject(String jsonData){

        List<MusicBean> list = new ArrayList<MusicBean>();
        try {
            JSONObject jsonObj = new JSONObject(jsonData);
            //int code = jsonObj.getInt("code");
            //System.out.println("code:"+code);
            JSONObject data = jsonObj.getJSONObject("result");

            //JSONObject comment = playlist.getJSONObject(0);
            JSONArray dailySongs = data.getJSONArray("songs");
            for (int i = 0; i < dailySongs.length(); i++) {
                JSONObject music = dailySongs.getJSONObject(i);

                String musicname = music.getString("name");
                String musicid = music.getString("id");
                JSONArray ar = music.getJSONArray("artists");

                JSONObject aurhor1 = ar.getJSONObject(0);
                String authorname = aurhor1.getString("name");

                JSONObject album = music.getJSONObject("album");
                String albumname = album.getString("name");
                //JSONObject al = music.getJSONObject("al");
                String picUrl = aurhor1.getString("img1v1Url");
                //String musicurl =getmusicurl(getmusicurljson(musicid));
                System.out.println("得到数据"+musicid+musicname);
                MusicBean mb = new MusicBean();
                mb.setAuthorname(authorname);
                mb.setImagurl(picUrl);
                mb.setName(musicname);
                mb.setId(musicid);
                mb.setAlbum(albumname);
                list.add(mb);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private void getmusicurljson(MusicBean mb){
        new Thread(new Runnable() {

            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {

                    URL url = new URL("https://netease-cloud-music-api-mocha-kappa.vercel.app/song/url?id="+mb.getId());
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new
                            InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null)
                        response.append(line);
                    Message message = new Message();
                    message.what = FindMUSICURL;
                    message.obj = response.toString();
                    handler.sendMessage(message);
                    //
                    //
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (connection != null)
                        connection.disconnect();

                }
            }
        }).start();


    }

    private String  getmusicurl(String jsonData){
        String musicurl="";
        try {
            JSONObject jsonObj = new JSONObject(jsonData);

            JSONArray data = jsonObj.getJSONArray("data");

            JSONObject data1 = data.getJSONObject(0);
            musicurl = data1.getString("url");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return musicurl;
    }
}