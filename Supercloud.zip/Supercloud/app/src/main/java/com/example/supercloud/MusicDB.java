package com.example.supercloud;



import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MusicDB extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "musices";
    public static final String NAME = "name";
    public static final String ID = "_id";
    public static final String MUSICID = "musicid";
    public static final String AUTHOR = "author";
    public static final String PATH = "path";
    public static final String ALBUM = "album";


    public MusicDB(@Nullable Context context) {
        super(context, "musices", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "("
                + ID + " INTEGER  PRIMARY KEY AUTOINCREMENT,"
                + NAME + " TEXT NOT NULL,"
                + MUSICID + " TEXT NOT NULL,"
                + AUTHOR + " TEXT NOT NULL,"
                + PATH + " TEXT NOT NULL,"
                + ALBUM + " TEXT NOT NULL )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
