package com.example.supercloud;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;

public class ListenAcitvity extends AppCompatActivity {
    protected static final String TAG = "jyh";
    String onlistenname,onlistenid,url;
    private MediaPlayer mp = new MediaPlayer();
    private Button start,stop,pause;
    private ProgressBar progressBar;
    private TextView textView;
    private Button button;
    private int FileLength;
    private int DownedFileLength = 0;
    private InputStream inputStream;
    private URLConnection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen_acitvity);
        onlistenname = getIntent().getStringExtra("onlistenname");
        onlistenid = getIntent().getStringExtra("onlistenid");
        url = getIntent().getStringExtra("onlistenurl");
        Log.d(TAG, "获得数据"+onlistenid+onlistenname+url);

        start = (Button)findViewById(R.id.start);
        stop = (Button)findViewById(R.id.stop);
        pause = (Button)findViewById(R.id.pause);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!mp.isPlaying()){
                    mp.start();
                }
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mp.isPlaying())
                    mp.stop();
            }
        });
        intlisten();

    }
    private void intlisten(){
        //GlobalFile gf = new GlobalFile();

        //MediaPlayer mediaPlayer = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        try {
            mp.setDataSource(url);
            System.out.println(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mp.prepare(); // might take long! (for buffering, etc)
        } catch (IOException e) {
            e.printStackTrace();
        }
        mp.start();

    }
}