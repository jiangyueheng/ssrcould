package com.example.supercloud;



import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by zejian
 * Time 16/9/3.
 * Description:
 */
public  class MyIntentService extends IntentService {

    private  final  String TAG="MyIntentService";
    private  String Url ;
    private  String fileName ;
    private  String filePath ;



    private int FileLength;
    private int DownedFileLength = 0;
    private InputStream inputStream;
    private URLConnection connection;
    private Handler handler;

    @Override
    public void onCreate() {

        super.onCreate();
    }

    public MyIntentService(){
        super("MyIntentService");
    }

    private void setHandler(){

    }
    /**
     * 实现异步任务的方法
     * @param intent Activity传递过来的Intent,数据封装在intent中
     */
    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        Url = extras.getString("url");
        filePath = extras.getString("path");
        fileName=extras.getString("name");
        if (TextUtils.isEmpty(Url)||TextUtils.isEmpty(fileName)||TextUtils.isEmpty(filePath)){
            Log.i(TAG,"url,path,name,key不能为空");
            return;
        }
        Downloadmm(Url,filePath,fileName);//执行下载程序


    }

    private void Downloadmm(String urlss,String filePath,String fileName){

        try {
            URL url = new URL(urlss);
            connection = url.openConnection();
            if (connection.getReadTimeout() == 5) {
                Log.i("---------->", "当前网络有问题");
                // return;
            }
            inputStream = connection.getInputStream();

        } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        /*
         * 文件的保存路径和和文件名其中Nobody.mp3是在手机SD卡上要保存的路径，如果不存在则新建
         */
        String savePAth = Environment.getExternalStorageDirectory() + filePath;
        File file1 = new File(savePAth);
        if (!file1.exists()) {
            file1.mkdir();
        }

        String savePathString = Environment.getExternalStorageDirectory() + filePath + fileName;
        File file = new File(savePathString);
        //verifyStoragePermissions(this);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rwd");
            randomAccessFile.setLength(FileLength);
            byte[] buf = new byte[1024 * 4];
            //FileLength = connection.getContentLength();
            handler=new Handler(Looper.getMainLooper());
            handler.post(new Runnable(){
                public void run(){
                    Toast.makeText(getApplicationContext(), "开始下载" , Toast.LENGTH_SHORT).show();
                }
            });

            int length = 0;
            while ((length = inputStream.read(buf)) != -1) {
                randomAccessFile.write(buf, 0, length);
                DownedFileLength += length;
                Log.i("-------->", DownedFileLength + "");
                Message message1 = new Message();
                message1.what = 1;
                //handler.sendMessage(message1);
                Intent myIntent1 = new Intent();//创建Intent对象
                myIntent1.setAction("com.example.supercloud.DownloadActivity");
                myIntent1.putExtra("kind", "1");
                myIntent1.putExtra("DownedFileLength", DownedFileLength);
                sendBroadcast(myIntent1);//发送广播
            }
            inputStream.close();
            randomAccessFile.close();

            handler=new Handler(Looper.getMainLooper());
            handler.post(new Runnable(){
                public void run(){
                    Toast.makeText(getApplicationContext(), "下载完成" , Toast.LENGTH_SHORT).show();
                }
            });

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }






}