package com.example.supercloud;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class SelectActivity extends AppCompatActivity {

    private MusicDB musicDB;
    private SQLiteDatabase dbReader;
    private CAdapter cAdapter;
    private ListView lv;
    //private String musicname,authorname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
        lv = (ListView)findViewById(R.id.ssmusiclist);
        musicDB = new MusicDB(this);
        dbReader = musicDB.getReadableDatabase();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("Range")
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = dbReader.query(musicDB.TABLE_NAME,null,null,null,null,null,null);
                cursor.moveToPosition(position);
                Intent i = new Intent(SelectActivity.this,listenmusicActivity.class);
                i.putExtra(MusicDB.ID,cursor.getInt(cursor.getColumnIndex(MusicDB.ID)));
                i.putExtra(MusicDB.NAME,cursor.getString(cursor.getColumnIndex(MusicDB.NAME)));
                i.putExtra(MusicDB.AUTHOR,cursor.getString(cursor.getColumnIndex(MusicDB.AUTHOR)));
                i.putExtra(MusicDB.ALBUM,cursor.getString(cursor.getColumnIndex(MusicDB.ALBUM)));
                i.putExtra(MusicDB.PATH,cursor.getString(cursor.getColumnIndex(MusicDB.PATH)));

                startActivity(i);

            }
        });
    }
    public void selectDB(){
        Cursor cursor = dbReader.query(musicDB.TABLE_NAME,null,null,null,null,null,null);
        cAdapter=new CAdapter(this,cursor);
        lv.setAdapter(cAdapter);

    }
    protected void onResume() {

        super.onResume();
        selectDB();
    }

    @Override
    protected void onDestroy() {
        dbReader.close();
        super.onDestroy();
    }
}