package com.example.supercloud;

import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Binder;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MyService extends Service {

    private LocalBinder binder = new LocalBinder();
    private final static String TAG = "wzj";
    private boolean quit;

    private int FileLength;
    private int DownedFileLength = 0;
    private InputStream inputStream;
    private URLConnection connection;
    private Handler handler;


    /**
     * 创建Binder对象，返回给客户端即Activity使用，提供数据交换的接口
     */
    public class LocalBinder extends Binder {
        // 声明一个方法，getService。（提供给客户端调用）
        MyService getService() {
            System.out.println("得到Sercice");
            // 返回当前对象LocalService,这样我们就可在客户端端调用Service的公共方法了
            return MyService.this;

        }

    }


    public MyService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();

    }

    private void DownFile(String urlString,String filePath,String fileName) {

        /*
         * 连接到服务器
         */

        try {
            URL url = new URL(urlString);
            connection = url.openConnection();
            if (connection.getReadTimeout() == 5) {
                Log.i("---------->", "当前网络有问题");
                // return;
            }
            inputStream = connection.getInputStream();

        } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        /*
         * 文件的保存路径和和文件名其中Nobody.mp3是在手机SD卡上要保存的路径，如果不存在则新建
         */
        String savePAth = Environment.getExternalStorageDirectory() + filePath;
        File file1 = new File(savePAth);
        if (!file1.exists()) {
            file1.mkdir();
        }
        String savePathString = Environment.getExternalStorageDirectory() + filePath + fileName;
        File file = new File(savePathString);
        //verifyStoragePermissions(this);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        /*
         * 向SD卡中写入文件,用Handle传递线程
         */
        Message message = new Message();
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rwd");
            randomAccessFile.setLength(FileLength);
            byte[] buf = new byte[1024 * 4];
            FileLength = connection.getContentLength();
            message.what = 0;
            handler.sendMessage(message);
            int length = 0;
            while ((length = inputStream.read(buf)) != -1) {
                randomAccessFile.write(buf, 0, length);
                DownedFileLength += length;
                Log.i("-------->", DownedFileLength + "");
                Message message1 = new Message();
                message1.what = 1;
                handler.sendMessage(message1);
            }
            inputStream.close();
            randomAccessFile.close();
            Message message2 = new Message();
            message2.what = 2;
            handler.sendMessage(message2);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }







    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "Service is invoke onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "Service is invoke Destroyed");
        this.quit = true;
        super.onDestroy();
    }
}