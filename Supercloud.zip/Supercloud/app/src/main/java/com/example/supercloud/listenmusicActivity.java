package com.example.supercloud;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;

public class listenmusicActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton play,pause,stop,volume_plus,volume_decrease;
    private TextView musicName,musicLength,musicCur;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer = new MediaPlayer();
    private AudioManager audioManager;
    private Timer timer;
    private boolean isSeekBarChanging;//互斥变量，防止进度条与定时器冲突。
    private int currentPosition;//当前音乐播放的进度
    SimpleDateFormat format;
    private String musicname;
    private String path;
    private String author;
    private int id;
    private MusicDB musicDB;
    private SQLiteDatabase dbReader;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen);

       intview();
        System.out.println("lujing"+path);

        if (ContextCompat.checkSelfPermission(listenmusicActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(listenmusicActivity.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }else {
            initMediaPlayer();//初始化mediaplayer
        }
        addprogress();
        count = getCount();


    }public int getCount() {//从数据库获取歌曲总数

        Cursor cursor = dbReader.rawQuery("select count(*) from musices",null);
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        cursor.close();
        return count;
    }
    private void next(int nn){//nn控制歌曲移动
        String querySql="select * from "+MusicDB.TABLE_NAME+" where "+MusicDB.ID+"=?";

            id=id+nn;
            if(id<=0){
                id+=count;
            }
            if(id>count){
                id-=count;
            }

        String nnm =String.valueOf(id);
        String []args=new String[]{nnm};
        // 返回值是一个Cursor对象
        Cursor cursor= dbReader.rawQuery(querySql,args);
        cursor.moveToNext();
        System.out.println("test"+musicname+id);
        musicname = cursor.getString(1);//获取第二列的值
        path = cursor.getString(4);
        author = cursor.getString(3);
        mediaPlayer.reset();//停止播放

        initMediaPlayer();
    }
    private void intview(){
        musicDB = new MusicDB(this);
        dbReader = musicDB.getReadableDatabase();
        audioManager = (AudioManager) getSystemService(Service.AUDIO_SERVICE);
        format = new SimpleDateFormat("mm:ss");
        play = (ImageButton) findViewById(R.id.last);
        pause = (ImageButton) findViewById(R.id.pause);
        stop = (ImageButton) findViewById(R.id.stop);
        musicName = (TextView) findViewById(R.id.music_name);
        musicLength = (TextView) findViewById(R.id.music_length);
        musicCur = (TextView) findViewById(R.id.music_cur);

        seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new MySeekBar());

        play.setOnClickListener(listenmusicActivity.this);
        pause.setOnClickListener(listenmusicActivity.this);
        stop.setOnClickListener(listenmusicActivity.this);
        musicname =getIntent().getStringExtra(MusicDB.NAME);
        path =getIntent().getStringExtra(MusicDB.PATH);
        id=getIntent().getIntExtra(MusicDB.ID,0);
    }
    private void initMediaPlayer() {
        try {
            File file = new File(Environment.getExternalStorageDirectory(),path);
            mediaPlayer.setDataSource(file.getPath());//指定音频文件的路径
            mediaPlayer.prepare();//让mediaplayer进入准备状态
            mediaPlayer.setLooping(true);
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mp) {
                    seekBar.setMax(mediaPlayer.getDuration());
                    musicLength.setText(format.format(mediaPlayer.getDuration())+"");
                    musicCur.setText("00:00");
                    musicName.setText(musicname);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initMediaPlayer();
                } else {
                    Toast.makeText(listenmusicActivity.this,"denied access",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
        }
    }

    private void addprogress(){
        mediaPlayer.seekTo(currentPosition);

        //监听播放时回调函数
        timer = new Timer();
        timer.schedule(new TimerTask() {

            Runnable updateUI = new Runnable() {
                @Override
                public void run() {
                    musicCur.setText(format.format(mediaPlayer.getCurrentPosition())+"");
                }
            };
            @Override
            public void run() {
                if(!isSeekBarChanging){
                    seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    runOnUiThread(updateUI);
                }
            }
        },0,50);
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.last://上一首
                next(-1);
                break;
            case R.id.pause:
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();//暂停播放
                }else if (!mediaPlayer.isPlaying()) {
                        mediaPlayer.start();//开始播放


                }
                break;
            case R.id.stop://下一首
                Toast.makeText(listenmusicActivity.this,"下一首",Toast.LENGTH_SHORT).show();
                next(1);
                break;

            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isSeekBarChanging = true;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (timer != null){
            timer.cancel();
            timer = null;
        }
    }

    /*进度条处理*/
    public class MySeekBar implements SeekBar.OnSeekBarChangeListener {

        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
        }

        /*滚动时,应当暂停后台定时器*/
        public void onStartTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = true;
        }
        /*滑动结束后，重新设置值*/
        public void onStopTrackingTouch(SeekBar seekBar) {
            isSeekBarChanging = false;
            mediaPlayer.seekTo(seekBar.getProgress());
        }

    }

}